"""
Test python file
"""


def main() -> None:
    print("Or-eh-gah-no? What the hell?")


main()
