"""
Test python file
"""

def main() -> None:
    print("All work and no play make Homer something something")

main()

